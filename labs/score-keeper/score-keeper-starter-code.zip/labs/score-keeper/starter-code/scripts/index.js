/* 
start a "score" at zero
when I click the first button, reset the score to zero
when I click the second button, add 5 to the current score
when I click the third button, add 10 to the current score
when I click the fourth button, minus 1 from the current score
each time I click a button, check that the total is not too big or too small
and update the score on the page
*/
